class_name Car
extends VehicleBody3D
## Машина на VehicleBody3D. Перед = -Z. Привод (FWD/RWD/AWD), коробка, обороты, топливо, урон.

signal damaged(amount: float)

@export var car_id: String = "cobalt"

var spec: Dictionary
var gear: int = 1              # -1 задний, 1..N
var rpm: float = 850.0
var fuel: float = 20.0
var damage: float = 0.0        # 0..1
var auto_gearbox: bool = true
var steer_sens: float = 1.0
var speed_kmh: float = 0.0
var plate: String = ""
var power_mult: float = 1.0    # для тюнинга (этап 7)
var grip_mult: float = 1.0     # для погоды (этап 11)
var lights_on: bool = false
var using_placeholder: bool = true
var body_color: Color = Color("#d8d8d8")

const MIX := 22050.0

var _wheels: Array[VehicleWheel3D] = []
var _plates: Array[PlateNode] = []
var _spots: Array[SpotLight3D] = []
var _body_mat: StandardMaterial3D
var _lamp_mat: StandardMaterial3D
var _tail_mat: StandardMaterial3D
var _model: Node3D
var _steer: float = 0.0
var _shift_cd: float = 0.0
var _last_vel: Vector3 = Vector3.ZERO
var _traction: int = 0
var _eng: AudioStreamPlayer
var _phase: float = 0.0
var _horn_t: float = 0.0

func _ready() -> void:
	spec = CarData.CARS[car_id]
	mass = spec.mass
	center_of_mass_mode = RigidBody3D.CENTER_OF_MASS_MODE_CUSTOM
	center_of_mass = spec.com
	angular_damp = 1.0
	contact_monitor = true
	max_contacts_reported = 4
	body_entered.connect(_on_hit)
	fuel = minf(fuel, spec.tank_l)

	var cs := CollisionShape3D.new()
	var bs := BoxShape3D.new()
	bs.size = Vector3(spec.width, 1.05, spec.length)
	cs.shape = bs
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)

	_make_light_mats()
	var path := "res://assets/cars/%s.glb" % car_id
	if ResourceLoader.exists(path):
		_model = (load(path) as PackedScene).instantiate()
		add_child(_model)
		using_placeholder = false
	else:
		_build_placeholder()

	var hx: float = spec.track * 0.5
	var wb: float = spec.wheelbase * 0.5
	_add_wheel(Vector3(-hx, 0.45, -wb), true)
	_add_wheel(Vector3(hx, 0.45, -wb), true)
	_add_wheel(Vector3(-hx, 0.45, wb), false)
	_add_wheel(Vector3(hx, 0.45, wb), false)
	_build_lights()
	_build_plates()
	_setup_audio()

# ---------------- построение ----------------

func _make_light_mats() -> void:
	_lamp_mat = StandardMaterial3D.new()
	_lamp_mat.albedo_color = Color(0.9, 0.9, 0.85)
	_lamp_mat.emission_enabled = true
	_lamp_mat.emission = Color(1.0, 0.95, 0.8)
	_lamp_mat.emission_energy_multiplier = 0.0
	_tail_mat = StandardMaterial3D.new()
	_tail_mat.albedo_color = Color(0.5, 0.02, 0.02)
	_tail_mat.emission_enabled = true
	_tail_mat.emission = Color(1.0, 0.05, 0.05)
	_tail_mat.emission_energy_multiplier = 0.0

func _box(size: Vector3, pos: Vector3, mat: Material) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	add_child(mi)

## ЗАГЛУШКА вместо модели: появляется только пока нет assets/cars/<id>.glb
func _build_placeholder() -> void:
	var L: float = spec.length
	var W: float = spec.width
	_body_mat = StandardMaterial3D.new()
	_body_mat.albedo_color = body_color
	_body_mat.metallic = 0.6
	_body_mat.roughness = 0.35
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color(0.08, 0.12, 0.16, 0.7)
	glass.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_box(Vector3(W, 0.5, L), Vector3(0, 0.62, 0), _body_mat)
	_box(Vector3(W - 0.14, 0.5, L * 0.5), Vector3(0, 1.12, 0.25), glass)
	_box(Vector3(W - 0.14, 0.05, L * 0.5), Vector3(0, 1.39, 0.25), _body_mat)
	for sx in [-1.0, 1.0]:
		_box(Vector3(0.28, 0.12, 0.05), Vector3(sx * 0.62, 0.74, -L / 2.0 - 0.01), _lamp_mat)
		_box(Vector3(0.26, 0.12, 0.05), Vector3(sx * 0.62, 0.76, L / 2.0 + 0.01), _tail_mat)

func _add_wheel(pos: Vector3, front: bool) -> void:
	var w := VehicleWheel3D.new()
	w.position = pos
	w.use_as_steering = front
	var d: String = spec.drive
	w.use_as_traction = (d == "AWD") or (d == "FWD" and front) or (d == "RWD" and not front)
	if w.use_as_traction:
		_traction += 1
	w.wheel_radius = spec.wheel_radius
	w.wheel_rest_length = 0.15
	w.suspension_travel = spec.susp_travel
	w.suspension_stiffness = spec.susp_stiffness
	w.damping_compression = spec.damp_comp
	w.damping_relaxation = spec.damp_rel
	w.suspension_max_force = mass * 8.0
	w.wheel_friction_slip = spec.grip
	w.wheel_roll_influence = 0.25
	add_child(w)
	_wheels.append(w)
	var tire := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = spec.wheel_radius
	cm.bottom_radius = spec.wheel_radius
	cm.height = 0.19
	var tm := StandardMaterial3D.new()
	tm.albedo_color = Color(0.05, 0.05, 0.05)
	cm.material = tm
	tire.mesh = cm
	tire.rotation_degrees = Vector3(0, 0, 90)
	w.add_child(tire)
	var rim := MeshInstance3D.new()
	var rm := CylinderMesh.new()
	rm.top_radius = 0.19
	rm.bottom_radius = 0.19
	rm.height = 0.2
	var rmat := StandardMaterial3D.new()
	rmat.albedo_color = Color(0.7, 0.7, 0.72)
	rmat.metallic = 0.9
	rmat.roughness = 0.3
	rm.material = rmat
	rim.mesh = rm
	rim.rotation_degrees = Vector3(0, 0, 90)
	w.add_child(rim)

func _build_lights() -> void:
	var L: float = spec.length
	for sx in [-1.0, 1.0]:
		var s := SpotLight3D.new()
		s.position = Vector3(sx * spec.headlight_x, spec.headlight_y, -L / 2.0)
		s.rotation_degrees.x = -3.0
		s.spot_range = 45.0
		s.spot_angle = 32.0
		s.light_energy = 4.0
		s.visible = false
		add_child(s)
		_spots.append(s)

func _build_plates() -> void:
	var f := PlateNode.new()
	f.position = spec.plate_front
	add_child(f)
	f.build(true)
	var r := PlateNode.new()
	r.position = spec.plate_rear
	add_child(r)
	r.build(false)
	_plates = [f, r]

func _setup_audio() -> void:
	## Синтетический звук двигателя (пилообразная волна от оборотов) - заглушка до этапа со звуками
	_eng = AudioStreamPlayer.new()
	var g := AudioStreamGenerator.new()
	g.mix_rate = MIX
	g.buffer_length = 0.15
	_eng.stream = g
	_eng.volume_db = -8.0
	add_child(_eng)
	_eng.play()

# ---------------- публичное ----------------

func set_plate(p: String) -> bool:
	var norm := KZPlate.parse(p)
	if norm == "":
		return false
	plate = norm
	for pl in _plates:
		pl.set_plate(norm)
	return true

func set_color(c: Color) -> void:
	body_color = c
	if _body_mat:
		_body_mat.albedo_color = c
	if _model:
		_recolor(_model, c)

func set_lights(on: bool) -> void:
	if on == lights_on:
		return
	lights_on = on
	for s in _spots:
		s.visible = on
	_lamp_mat.emission_energy_multiplier = 3.0 if on else 0.0

func shift(dir: int) -> void:
	if auto_gearbox:
		return
	gear = clampi(gear + dir, 1, spec.gears.size())

func repair() -> void:
	damage = 0.0

func _recolor(node: Node, c: Color) -> void:
	if node is MeshInstance3D:
		var mi := node as MeshInstance3D
		if mi.mesh:
			for i in mi.mesh.get_surface_count():
				var m := mi.mesh.surface_get_material(i)
				if m is StandardMaterial3D and m.resource_name == "Body":
					var d := (m as StandardMaterial3D).duplicate() as StandardMaterial3D
					d.albedo_color = c
					mi.set_surface_override_material(i, d)
	for ch in node.get_children():
		_recolor(ch, c)

# ---------------- физика ----------------

func _ratio() -> float:
	if gear < 0:
		return spec.reverse_ratio
	return spec.gears[clampi(gear, 1, spec.gears.size()) - 1]

func _torque(r: float) -> float:
	var x: float = (r - spec.peak_torque_rpm) / (spec.max_rpm - spec.idle_rpm)
	return spec.peak_torque * clampf(1.0 - 1.6 * x * x, 0.35, 1.0)

func _physics_process(delta: float) -> void:
	var fwd: float = linear_velocity.dot(-global_transform.basis.z)
	speed_kmh = absf(fwd) * 3.6
	var throttle: float = Input.get_action_strength("throttle")
	var brake_in: float = Input.get_action_strength("brake")
	var hand: bool = Input.is_action_pressed("handbrake")
	if fuel <= 0.0:
		throttle = 0.0

	# Тормоз с места = задний ход
	var reverse: bool = brake_in > 0.05 and throttle < 0.05 and fwd < 1.0
	if reverse:
		gear = -1
	elif gear == -1 and throttle > 0.05:
		gear = 1

	# Обороты
	var ratio: float = _ratio()
	var wheel_rpm: float = absf(fwd) / (TAU * spec.wheel_radius) * 60.0
	var kin_rpm: float = wheel_rpm * ratio * spec.final_drive
	var target_rpm: float = maxf(kin_rpm, spec.idle_rpm + throttle * 2200.0)
	rpm = lerpf(rpm, minf(target_rpm, spec.max_rpm), clampf(12.0 * delta, 0.0, 1.0))

	# Автоматическая коробка
	_shift_cd = maxf(0.0, _shift_cd - delta)
	if auto_gearbox and gear >= 1 and _shift_cd <= 0.0:
		if kin_rpm > spec.max_rpm * 0.88 and gear < spec.gears.size():
			gear += 1
			_shift_cd = 0.45
		elif gear > 1 and kin_rpm < spec.max_rpm * 0.36:
			gear -= 1
			_shift_cd = 0.45
	if Input.is_action_just_pressed("shift_up"):
		shift(1)
	if Input.is_action_just_pressed("shift_down"):
		shift(-1)

	# Тяга
	var f: float = 0.0
	var wr: float = spec.final_drive / spec.wheel_radius * 0.85
	if reverse:
		if fwd > -8.0:
			f = -_torque(maxf(rpm, 2000.0)) * brake_in * ratio * wr
	elif throttle > 0.0 and rpm < spec.max_rpm * 0.995:
		f = _torque(maxf(rpm, 2000.0)) * throttle * ratio * wr
	f *= (1.0 - damage * 0.4) * power_mult
	engine_force = f / float(maxi(_traction, 1))

	# Тормоза и ручник (ручник: задние колёса блокируются и теряют сцепление)
	var brake_amt: float = 0.0 if reverse else brake_in
	var base: float = mass * 0.028 * spec.brake_mult
	for w in _wheels:
		var front: bool = w.use_as_steering
		var b: float = brake_amt * base * (1.15 if front else 0.85)
		var slip: float = spec.grip * grip_mult
		if hand and not front:
			b = maxf(b, mass * 0.06)
			slip *= 0.5
		w.brake = b
		w.wheel_friction_slip = slip

	# Руль (чем быстрее, тем меньше угол)
	var s_in: float = Input.get_axis("steer_right", "steer_left")
	var max_a: float = lerpf(0.55, 0.12, clampf(speed_kmh / 120.0, 0.0, 1.0)) * steer_sens
	max_a = minf(max_a, 0.75)
	_steer = move_toward(_steer, s_in * max_a, delta * (2.5 if s_in != 0.0 else 4.0))
	steering = _steer

	# Сопротивление воздуха и торможение двигателем
	var spd: float = linear_velocity.length()
	apply_central_force(-linear_velocity * spd * spec.drag)
	if throttle < 0.02 and brake_amt < 0.02 and not reverse and spd > 0.3:
		apply_central_force(-linear_velocity.normalized() * mass * 0.4)

	# Топливо (приближённая модель)
	if fuel > 0.0:
		fuel = maxf(0.0, fuel - (0.0001 + throttle * (rpm / spec.max_rpm) * 0.007) * delta)

	# Стоп-сигналы
	if brake_in > 0.05:
		_tail_mat.emission_energy_multiplier = 4.0
	else:
		_tail_mat.emission_energy_multiplier = 1.2 if lights_on else 0.0

	_last_vel = linear_velocity

func _on_hit(_body: Node) -> void:
	var dv: float = (_last_vel - linear_velocity).length()
	if dv > 4.0:
		var d: float = clampf((dv - 4.0) / 30.0, 0.0, 0.5)
		damage = clampf(damage + d, 0.0, 1.0)
		damaged.emit(d)

# ---------------- звук ----------------

func _process(_d: float) -> void:
	var pb := _eng.get_stream_playback() as AudioStreamGeneratorPlayback
	if pb == null:
		return
	var n := pb.get_frames_available()
	var f: float = rpm / 60.0 * 2.0
	var amp: float = 0.05 + 0.07 * Input.get_action_strength("throttle")
	var horn: bool = Input.is_action_pressed("horn")
	for i in n:
		_phase = fmod(_phase + f / MIX, 1.0)
		var s: float = ((_phase * 2.0 - 1.0) * 0.6 + sin(_phase * TAU * 2.0) * 0.4) * amp
		if horn:
			_horn_t = fmod(_horn_t + 1.0 / MIX, 1.0)
			s += (sin(TAU * 420.0 * _horn_t) + sin(TAU * 520.0 * _horn_t)) * 0.06
		pb.push_frame(Vector2(s, s))
