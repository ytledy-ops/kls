class_name CarData
extends RefCounted
## Характеристики машин. Значения ориентировочные (не заводские) - подгоняются тестами.
## Чтобы добавить машину: новая запись + assets/cars/<id>.glb

const CARS := {
	"cobalt": {
		"name": "Chevrolet Cobalt",
		"price": 0,
		"mass": 1100.0,
		"drive": "FWD",            # FWD / RWD / AWD
		"power_hp": 106.0,
		"peak_torque": 141.0,      # Н·м
		"peak_torque_rpm": 4000.0,
		"idle_rpm": 850.0,
		"max_rpm": 6200.0,
		"gears": [3.73, 2.14, 1.42, 1.03, 0.82],
		"final_drive": 4.06,
		"reverse_ratio": 3.55,
		"wheel_radius": 0.30,
		"length": 4.50, "width": 1.74, "height": 1.50,
		"wheelbase": 2.62, "track": 1.48,
		"tank_l": 45.0,
		"drag": 0.42, "grip": 3.4, "brake_mult": 1.0,
		"susp_stiffness": 40.0, "susp_travel": 0.20,
		"damp_comp": 3.0, "damp_rel": 3.6,
		"com": Vector3(0, 0.50, -0.15),
		"plate_front": Vector3(0, 0.55, -2.26),
		"plate_rear": Vector3(0, 0.62, 2.26),
		"headlight_x": 0.62, "headlight_y": 0.76,
	},
}
