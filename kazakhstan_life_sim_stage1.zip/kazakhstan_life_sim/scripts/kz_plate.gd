class_name KZPlate
extends RefCounted
## Казахстанский формат: 123 ABC 02 (3 цифры, 3 буквы, код региона)

const REGIONS := {
	"01": "Астана", "02": "Алматы", "03": "Акмолинская область",
	"05": "Алматинская область", "07": "Западно-Казахстанская область",
	"10": "Абайская область", "11": "Жамбылская область",
	"13": "Туркестанская область", "17": "Шымкент",
}
# Набор букв для генерации NPC-номеров (приблизительный, сверьте с реальным списком)
const LETTERS := "ABCDEFGHJKLMNPRSTUVXYZ"

static func random_plate(region: String = "") -> String:
	var rng := RandomNumberGenerator.new()
	rng.randomize()
	if region == "" or not REGIONS.has(region):
		region = REGIONS.keys()[rng.randi() % REGIONS.size()]
	var lets := ""
	for i in 3:
		lets += LETTERS[rng.randi() % LETTERS.length()]
	return "%03d %s %s" % [rng.randi_range(1, 999), lets, region]

## Возвращает нормализованный номер или "" если формат неверный.
static func parse(text: String) -> String:
	var re := RegEx.new()
	re.compile("^(\\d{3})\\s*([A-Za-z]{3})\\s*(\\d{2})$")
	var m := re.search(text.strip_edges())
	if m == null:
		return ""
	var region := m.get_string(3)
	if not REGIONS.has(region):
		return ""
	return "%s %s %s" % [m.get_string(1), m.get_string(2).to_upper(), region]

static func main_text(p: String) -> String:
	return p.substr(0, 7)

static func region_code(p: String) -> String:
	return p.substr(8, 2)
