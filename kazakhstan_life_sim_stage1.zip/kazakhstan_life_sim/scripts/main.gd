extends Node3D
## Этап 1: полигон (плоская дорога), машина игрока, камеры, день/ночь, HUD, радио, настройки.
## Город - этап 2.

const FUEL_PRICE := 250.0          # ₸ за литр
const REPAIR_COST_FULL := 40000.0  # ₸ за 100% повреждений
const DAY_SECONDS := 1200.0        # сутки в игре = 20 минут

var car: Car
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var sky_mat: ProceduralSkyMaterial
var cam_mode: int = 0
var time_of_day: float = 9.0

var _l_money: Label
var _l_speed: Label
var _l_gear: Label
var _l_info: Label
var _l_toast: Label
var _b_rpm: ProgressBar
var _shift_btns: Array[Control] = []
var _radio_ui: Control
var _menu_ui: Control
var _toast_t: float = 0.0

func _ready() -> void:
	Engine.max_fps = 60
	_setup_input()
	time_of_day = Save.data.time
	_build_world()
	_spawn_car()
	_build_hud()
	_apply_graphics(int(Save.data.settings.graphics))
	_update_camera(1.0)

# ---------------- ввод ----------------

func _setup_input() -> void:
	var map := {
		"throttle": [KEY_W, KEY_UP], "brake": [KEY_S, KEY_DOWN],
		"steer_left": [KEY_A, KEY_LEFT], "steer_right": [KEY_D, KEY_RIGHT],
		"handbrake": [KEY_SPACE], "shift_up": [KEY_E], "shift_down": [KEY_Q],
		"horn": [KEY_H], "camera": [KEY_C], "radio": [KEY_R],
	}
	for a in map:
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		for k in map[a]:
			var e := InputEventKey.new()
			e.physical_keycode = k as Key
			InputMap.action_add_event(a, e)

func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("camera"):
		_on_camera()
	elif event.is_action_pressed("radio"):
		_on_radio()

# ---------------- мир (полигон) ----------------

func _mat(c: Color, rough: float = 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	return m

func _build_world() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	var sky := Sky.new()
	sky_mat = ProceduralSkyMaterial.new()
	sky.sky_material = sky_mat
	env.background_mode = Environment.BG_SKY
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	we.environment = env
	add_child(we)

	sun = DirectionalLight3D.new()
	sun.shadow_enabled = true
	add_child(sun)

	cam = Camera3D.new()
	cam.fov = 70.0
	cam.near = 0.1
	cam.far = 1500.0
	add_child(cam)
	cam.current = true

	# земля
	var ground := StaticBody3D.new()
	var gs := CollisionShape3D.new()
	var gb := BoxShape3D.new()
	gb.size = Vector3(4000, 2, 4000)
	gs.shape = gb
	gs.position = Vector3(0, -1, 0)
	ground.add_child(gs)
	var gm := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(4000, 4000)
	pm.material = _mat(Color(0.28, 0.33, 0.2))
	gm.mesh = pm
	ground.add_child(gm)
	add_child(ground)

	# дорога вдоль Z
	var road := MeshInstance3D.new()
	var rm := PlaneMesh.new()
	rm.size = Vector2(14, 4000)
	rm.material = _mat(Color(0.12, 0.12, 0.13))
	road.mesh = rm
	road.position = Vector3(0, 0.02, 0)
	add_child(road)

	var dash: Array[Transform3D] = []
	for i in range(-250, 250):
		dash.append(Transform3D(Basis.IDENTITY, Vector3(0, 0.04, i * 8.0)))
	var dm := BoxMesh.new()
	dm.size = Vector3(0.2, 0.01, 3.0)
	dm.material = _mat(Color(0.9, 0.9, 0.9))
	_multimesh(dm, dash)

	var posts: Array[Transform3D] = []
	for i in range(-80, 80):
		posts.append(Transform3D(Basis.IDENTITY, Vector3(-9.0, 1.5, i * 50.0)))
		posts.append(Transform3D(Basis.IDENTITY, Vector3(9.0, 1.5, i * 50.0)))
	var cm := CylinderMesh.new()
	cm.top_radius = 0.08
	cm.bottom_radius = 0.08
	cm.height = 3.0
	cm.material = _mat(Color(0.5, 0.5, 0.55))
	_multimesh(cm, posts)

func _multimesh(mesh: Mesh, xf: Array[Transform3D]) -> void:
	var mm := MultiMesh.new()
	mm.transform_format = MultiMesh.TRANSFORM_3D
	mm.mesh = mesh
	mm.instance_count = xf.size()
	for i in xf.size():
		mm.set_instance_transform(i, xf[i])
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = mm
	add_child(mmi)

func _spawn_car() -> void:
	car = Car.new()
	car.car_id = Save.data.car_id
	car.position = Vector3(0, 0.9, 0)
	add_child(car)
	car.fuel = float(Save.data.fuel)
	car.damage = float(Save.data.damage)
	car.auto_gearbox = bool(Save.data.settings.auto_gearbox)
	car.steer_sens = float(Save.data.settings.steer_sens)
	car.set_color(Color.html(Save.data.color))
	var p := KZPlate.parse(Save.data.plate)
	if p == "":
		p = KZPlate.random_plate()
		Save.data.plate = p
	car.set_plate(p)

# ---------------- день/ночь, графика ----------------

func _update_sky() -> void:
	var elev: float = sin((time_of_day - 6.0) / 24.0 * TAU)
	var day: float = smoothstep(-0.12, 0.3, elev)
	sun.rotation_degrees = Vector3(-clampf(elev, 0.02, 1.0) * 80.0, -40.0, 0.0)
	sun.light_energy = 1.2 * day
	sun.visible = day > 0.01
	sky_mat.sky_top_color = Color(0.01, 0.02, 0.06).lerp(Color(0.25, 0.45, 0.8), day)
	var hz := Color(0.03, 0.04, 0.08).lerp(Color(0.7, 0.78, 0.88), day)
	sky_mat.sky_horizon_color = hz
	sky_mat.ground_horizon_color = hz
	sky_mat.ground_bottom_color = Color(0.02, 0.02, 0.03).lerp(Color(0.25, 0.28, 0.2), day)
	env.ambient_light_energy = lerpf(0.25, 1.0, day)
	car.set_lights(day < 0.4)

func _apply_graphics(q: int) -> void:
	var vp := get_viewport()
	match q:
		0:
			vp.scaling_3d_scale = 0.6
			sun.shadow_enabled = false
			vp.msaa_3d = Viewport.MSAA_DISABLED
		1:
			vp.scaling_3d_scale = 0.8
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 50.0
			vp.msaa_3d = Viewport.MSAA_DISABLED
		_:
			vp.scaling_3d_scale = 1.0
			sun.shadow_enabled = true
			sun.directional_shadow_max_distance = 100.0
			vp.msaa_3d = Viewport.MSAA_2X
	Save.data.settings.graphics = q

# ---------------- камера ----------------

func _physics_process(delta: float) -> void:
	_update_camera(delta)

func _update_camera(delta: float) -> void:
	var t := car.global_transform
	match cam_mode:
		0:
			var dist: float = 6.0 + car.speed_kmh / 40.0
			var target := t.origin + t.basis.z * dist + Vector3.UP * 2.4
			cam.global_position = cam.global_position.lerp(target, 1.0 - exp(-8.0 * delta))
			cam.look_at(t.origin + Vector3.UP * 1.1, Vector3.UP)
		1:
			_cam_to(t * Transform3D(Basis.IDENTITY, Vector3(0, 1.15, -0.9)), delta)
		2:
			_cam_to(t * Transform3D(Basis.IDENTITY, Vector3(-0.38, 1.25, 0.15)), delta)
		_:
			var b := Basis.from_euler(Vector3(-PI / 2.0, car.global_rotation.y, 0.0))
			_cam_to(Transform3D(b, t.origin + Vector3(0, 30, 0)), delta)

func _cam_to(target: Transform3D, delta: float) -> void:
	cam.global_transform = cam.global_transform.interpolate_with(target, 1.0 - exp(-15.0 * delta))

# ---------------- HUD ----------------

func _place(c: Control, ax: float, ay: float, x: float, y: float, w: float, h: float) -> void:
	c.anchor_left = ax
	c.anchor_right = ax
	c.anchor_top = ay
	c.anchor_bottom = ay
	c.offset_left = x
	c.offset_right = x + w
	c.offset_top = y
	c.offset_bottom = y + h

func _text(size: int, parent: Control, center: bool = false) -> Label:
	var l := Label.new()
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 6)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	if center:
		l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l

func _tap(text: String, cb: Callable, parent: Control) -> TapBtn:
	var b := TapBtn.new()
	b.text = text
	b.tapped.connect(cb)
	b.add_theme_font_size_override("font_size", 22)
	parent.add_child(b)
	return b

func _pedal(action: String, caption: String, ax: float, ay: float, x: float, y: float, w: float, h: float, parent: Control) -> void:
	var b := TouchBtn.new()
	b.action = action
	b.caption = caption
	parent.add_child(b)
	_place(b, ax, ay, x, y, w, h)

func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)

	_l_money = _text(30, root)
	_place(_l_money, 0, 0, 20, 10, 320, 40)
	_l_toast = _text(26, root, true)
	_place(_l_toast, 0.5, 0, -300, 72, 600, 40)

	var names := ["Меню", "РАДИО", "Камера", "Заправка", "Ремонт"]
	var cbs := [_on_menu, _on_radio, _on_camera, _refuel, _repair]
	for i in names.size():
		var b := _tap(names[i], cbs[i], root)
		_place(b, 1, 0, -(i + 1) * 138 - 6, 10, 130, 56)

	var up := _tap("Передача +", func(): car.shift(1), root)
	_place(up, 0, 0, 20, 60, 130, 50)
	var dn := _tap("Передача −", func(): car.shift(-1), root)
	_place(dn, 0, 0, 160, 60, 130, 50)
	_shift_btns = [up, dn]

	_l_speed = _text(72, root, true)
	_place(_l_speed, 0.5, 1, -150, -215, 300, 90)
	_l_gear = _text(26, root, true)
	_place(_l_gear, 0.5, 1, -150, -120, 300, 36)
	_b_rpm = ProgressBar.new()
	_b_rpm.show_percentage = false
	_b_rpm.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_b_rpm)
	_place(_b_rpm, 0.5, 1, -180, -78, 360, 16)
	_l_info = _text(20, root, true)
	_place(_l_info, 0.5, 1, -230, -54, 460, 34)

	_pedal("steer_left", "<", 0, 1, 20, -190, 135, 150, root)
	_pedal("steer_right", ">", 0, 1, 165, -190, 135, 150, root)
	_pedal("throttle", "ГАЗ", 1, 1, -200, -200, 180, 180, root)
	_pedal("brake", "ТОРМОЗ", 1, 1, -400, -170, 180, 150, root)
	_pedal("handbrake", "РУЧНИК", 1, 1, -400, -250, 180, 70, root)
	_pedal("horn", "СИГНАЛ", 1, 1, -200, -280, 180, 70, root)

	_radio_ui = preload("res://scripts/radio_ui.gd").new()
	root.add_child(_radio_ui)
	_place(_radio_ui, 0.5, 0, -260, 70, 520, 380)
	_radio_ui.hide()

	_menu_ui = preload("res://scripts/menu_ui.gd").new()
	root.add_child(_menu_ui)
	_place(_menu_ui, 0.5, 0, -260, 70, 520, 440)
	_menu_ui.sens_changed.connect(_on_sens)
	_menu_ui.graphics_changed.connect(_apply_graphics)
	_menu_ui.gearbox_changed.connect(_on_gearbox)
	_menu_ui.plate_applied.connect(_on_plate)
	_menu_ui.color_changed.connect(_on_color)
	_menu_ui.hide()

func _fmt(n: int) -> String:
	var s := str(absi(n))
	var out := ""
	var c := 0
	for i in range(s.length() - 1, -1, -1):
		out = s[i] + out
		c += 1
		if c % 3 == 0 and i > 0:
			out = " " + out
	return ("-" if n < 0 else "") + out

func _update_hud() -> void:
	_l_money.text = "%s ₸" % _fmt(int(Save.data.money))
	_l_speed.text = "%d" % int(car.speed_kmh)
	var g := "R" if car.gear < 0 else str(car.gear)
	_l_gear.text = "км/ч · передача %s %s" % [g, "(авто)" if car.auto_gearbox else "(мех.)"]
	_b_rpm.max_value = car.spec.max_rpm
	_b_rpm.value = car.rpm
	var hh := int(time_of_day)
	var mm := int((time_of_day - hh) * 60.0)
	_l_info.text = "Топливо %.1f/%d л · Повреждения %d%% · %02d:%02d" % [car.fuel, int(car.spec.tank_l), int(car.damage * 100.0), hh, mm]
	for b in _shift_btns:
		b.visible = not car.auto_gearbox

func _process(delta: float) -> void:
	time_of_day = fmod(time_of_day + delta * 24.0 / DAY_SECONDS, 24.0)
	_update_sky()
	_update_hud()
	Save.data.time = time_of_day
	Save.data.fuel = car.fuel
	Save.data.damage = car.damage
	if _toast_t > 0.0:
		_toast_t -= delta
		if _toast_t <= 0.0:
			_l_toast.text = ""

func _toast(msg: String) -> void:
	_l_toast.text = msg
	_toast_t = 3.0

# ---------------- действия ----------------

func _on_menu() -> void:
	_radio_ui.hide()
	_menu_ui.visible = not _menu_ui.visible

func _on_radio() -> void:
	_menu_ui.hide()
	_radio_ui.visible = not _radio_ui.visible

func _on_camera() -> void:
	cam_mode = (cam_mode + 1) % 4
	_toast(["Камера: сзади", "Камера: капот", "Камера: салон", "Камера: сверху"][cam_mode])

func _refuel() -> void:
	if car.speed_kmh > 5.0:
		_toast("Остановитесь для заправки")
		return
	var need: float = car.spec.tank_l - car.fuel
	var liters: float = minf(need, float(Save.data.money) / FUEL_PRICE)
	if liters < 0.5:
		_toast("Бак полон или не хватает денег")
		return
	var cost := int(ceil(liters * FUEL_PRICE))
	if Save.spend(cost):
		car.fuel += liters
		_toast("Заправлено %.1f л за %s ₸" % [liters, _fmt(cost)])

func _repair() -> void:
	if car.damage < 0.01:
		_toast("Ремонт не нужен")
		return
	var cost := int(ceil(car.damage * REPAIR_COST_FULL))
	if Save.spend(cost):
		car.repair()
		_toast("Отремонтировано за %s ₸" % _fmt(cost))
	else:
		_toast("Не хватает денег: нужно %s ₸" % _fmt(cost))

func _on_sens(v: float) -> void:
	car.steer_sens = v
	Save.data.settings.steer_sens = v

func _on_gearbox(auto: bool) -> void:
	car.auto_gearbox = auto
	Save.data.settings.auto_gearbox = auto

func _on_plate(p: String) -> void:
	car.set_plate(p)
	Save.data.plate = p

func _on_color(c: Color) -> void:
	car.set_color(c)
	Save.data.color = "#" + c.to_html(false)
