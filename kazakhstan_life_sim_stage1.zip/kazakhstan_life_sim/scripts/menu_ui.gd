extends PanelContainer
## Настройки: чувствительность руля, графика, коробка, цвет, госномер

signal sens_changed(v: float)
signal graphics_changed(i: int)
signal gearbox_changed(auto: bool)
signal plate_applied(p: String)
signal color_changed(c: Color)

var _plate_edit: LineEdit
var _msg: Label

func _ready() -> void:
	var v := VBoxContainer.new()
	add_child(v)
	var t := Label.new()
	t.text = "Настройки"
	v.add_child(t)

	var l1 := Label.new()
	l1.text = "Чувствительность руля"
	v.add_child(l1)
	var s := HSlider.new()
	s.min_value = 0.5
	s.max_value = 1.5
	s.step = 0.05
	s.value = float(Save.data.settings.steer_sens)
	s.value_changed.connect(func(x): sens_changed.emit(x))
	v.add_child(s)

	var g := OptionButton.new()
	g.add_item("Графика: низкая")
	g.add_item("Графика: средняя")
	g.add_item("Графика: высокая")
	g.selected = int(Save.data.settings.graphics)
	g.item_selected.connect(func(i): graphics_changed.emit(i))
	v.add_child(g)

	var cb := CheckButton.new()
	cb.text = "Автоматическая коробка"
	cb.button_pressed = bool(Save.data.settings.auto_gearbox)
	cb.toggled.connect(func(on): gearbox_changed.emit(on))
	v.add_child(cb)

	var cp := ColorPickerButton.new()
	cp.text = "Цвет кузова"
	cp.color = Color.html(Save.data.color)
	cp.custom_minimum_size = Vector2(0, 40)
	cp.color_changed.connect(func(c): color_changed.emit(c))
	v.add_child(cp)

	var l2 := Label.new()
	l2.text = "Госномер (пример: 777 ABC 02)"
	v.add_child(l2)
	var row := HBoxContainer.new()
	v.add_child(row)
	_plate_edit = LineEdit.new()
	_plate_edit.text = Save.data.plate
	_plate_edit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(_plate_edit)
	var ok := Button.new()
	ok.text = "Применить"
	ok.pressed.connect(_apply_plate)
	row.add_child(ok)
	var rnd := Button.new()
	rnd.text = "Случайный"
	rnd.pressed.connect(func():
		_plate_edit.text = KZPlate.random_plate()
		_apply_plate())
	row.add_child(rnd)
	_msg = Label.new()
	_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_msg.add_theme_font_size_override("font_size", 14)
	var regs: PackedStringArray = []
	for k in KZPlate.REGIONS:
		regs.append("%s %s" % [k, KZPlate.REGIONS[k]])
	_msg.text = "Регионы: " + ", ".join(regs)
	v.add_child(_msg)

	var close := Button.new()
	close.text = "Закрыть"
	close.pressed.connect(hide)
	v.add_child(close)

func _apply_plate() -> void:
	var p := KZPlate.parse(_plate_edit.text)
	if p == "":
		_msg.text = "Неверно. Формат: 123 ABC 02, регион из списка."
		return
	_plate_edit.text = p
	plate_applied.emit(p)
	_msg.text = "Номер установлен: " + p
