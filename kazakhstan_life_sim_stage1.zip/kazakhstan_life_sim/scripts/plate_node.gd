class_name PlateNode
extends Node3D
## 3D-табличка номера на кузове (Label3D на тонкой пластине)

var _main: Label3D
var _region: Label3D

func build(front: bool) -> void:
	if front:
		rotation.y = PI  # читается спереди
	_add_box(Vector3(0.52, 0.11, 0.012), Vector3.ZERO, Color(0.95, 0.95, 0.92))
	_add_box(Vector3(0.07, 0.11, 0.0125), Vector3(-0.225, 0, 0), Color(0.0, 0.45, 0.75))
	var kz := _label("KZ", 34, Color.WHITE)
	kz.position = Vector3(-0.225, 0, 0.0075)
	_main = _label("", 80, Color.BLACK)
	_main.position = Vector3(-0.03, 0, 0.0075)
	_region = _label("", 64, Color.BLACK)
	_region.position = Vector3(0.205, 0, 0.0075)

func set_plate(p: String) -> void:
	_main.text = KZPlate.main_text(p)
	_region.text = KZPlate.region_code(p)

func _add_box(size: Vector3, pos: Vector3, col: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	var mat := StandardMaterial3D.new()
	mat.albedo_color = col
	bm.material = mat
	mi.mesh = bm
	mi.position = pos
	add_child(mi)

func _label(t: String, size: int, col: Color) -> Label3D:
	var l := Label3D.new()
	l.text = t
	l.font_size = size
	l.pixel_size = 0.0007
	l.modulate = col
	l.shaded = false
	l.double_sided = false
	l.outline_size = 0
	add_child(l)
	return l
