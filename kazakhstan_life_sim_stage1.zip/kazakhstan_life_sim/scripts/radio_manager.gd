extends Node
## Автозагрузка "Radio": реальный поиск через Deezer API (без ключа) и воспроизведение 30-секундных превью.
## Deezer отдаёт MP3-превью; Godot умеет их декодировать. Полные треки API не отдаёт.

signal results_changed
signal track_changed(t: Dictionary)
signal cover_loaded(tex: Texture2D)
signal playing_changed(on: bool)
signal status(text: String)

const SEARCH_URL := "https://api.deezer.com/search?limit=25&q="

var results: Array = []
var queue: Array = []
var index: int = -1
var track: Dictionary = {}
var cover_tex: Texture2D = null
var volume: float = 0.8

var _player: AudioStreamPlayer
var _h_search: HTTPRequest
var _h_audio: HTTPRequest
var _h_cover: HTTPRequest
var _h_refresh: HTTPRequest
var _restore: bool = false
var _want_play: bool = true
var _retried: bool = false
var _paused_at: float = 0.0

func _ready() -> void:
	_player = AudioStreamPlayer.new()
	add_child(_player)
	_player.finished.connect(next)
	_h_search = _make_http(_on_search)
	_h_audio = _make_http(_on_audio)
	_h_cover = _make_http(_on_cover)
	_h_refresh = _make_http(_on_refresh)
	set_volume(Save.data.radio.volume)
	# Восстановление последнего плейлиста
	var q: String = Save.data.radio.query
	if q != "":
		_restore = true
		search(q)
	elif favorites().size() > 0:
		queue = favorites().duplicate()
		play_index(clampi(int(Save.data.radio.index), 0, queue.size() - 1), false)

func _make_http(cb: Callable) -> HTTPRequest:
	var h := HTTPRequest.new()
	h.timeout = 20.0
	h.use_threads = true
	h.request_completed.connect(cb)
	add_child(h)
	return h

# ---------- поиск ----------

func search(q: String) -> void:
	q = q.strip_edges()
	if q == "":
		return
	Save.data.radio.query = q
	status.emit("Поиск…")
	_h_search.cancel_request()
	if _h_search.request(SEARCH_URL + q.uri_encode()) != OK:
		status.emit("Нет сети")

func _parse(result: int, code: int, body: PackedByteArray) -> Array:
	var out: Array = []
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		return out
	var j = JSON.parse_string(body.get_string_from_utf8())
	if not (j is Dictionary) or not j.has("data"):
		return out
	for t in j["data"]:
		var prev: String = str(t.get("preview", ""))
		if prev == "":
			continue
		out.append({
			"id": t["id"],
			"title": str(t["title"]),
			"artist": str(t["artist"]["name"]),
			"cover": str(t["album"].get("cover_medium", "")),
			"preview": prev,
		})
	return out

func _on_search(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	var list := _parse(result, code, body)
	if list.is_empty():
		status.emit("Ничего не найдено или нет сети (код %d)" % code)
		_restore = false
		return
	results = list
	results_changed.emit()
	status.emit("Найдено: %d (превью 30 сек)" % list.size())
	if _restore:
		_restore = false
		queue = list.duplicate()
		play_index(clampi(int(Save.data.radio.index), 0, queue.size() - 1), false)
	elif queue.is_empty():
		queue = list.duplicate()

# ---------- воспроизведение ----------

func play_from(list: Array, i: int) -> void:
	queue = list.duplicate()
	play_index(i, true)

func play_index(i: int, autoplay: bool = true) -> void:
	if i < 0 or i >= queue.size():
		return
	index = i
	track = queue[i]
	_retried = false
	_want_play = autoplay
	_paused_at = 0.0
	_player.stop()
	Save.data.radio.index = i
	if autoplay:
		_add_history(track)
	track_changed.emit(track)
	_fetch_cover()
	_fetch_audio()

func _fetch_audio() -> void:
	status.emit("Загрузка превью…")
	_h_audio.cancel_request()
	_h_audio.request(str(track.preview))

func _on_audio(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200 or body.size() < 2000:
		if not _retried:
			_retried = true
			_refresh_preview()  # ссылки Deezer протухают - берём свежую
			return
		status.emit("Не удалось загрузить превью")
		return
	var s := AudioStreamMP3.new()
	s.data = body
	_player.stream = s
	if _want_play:
		_player.play()
		playing_changed.emit(true)
	else:
		playing_changed.emit(false)
	status.emit("Только превью 30 сек · источник Deezer")

func _refresh_preview() -> void:
	_h_refresh.cancel_request()
	_h_refresh.request(SEARCH_URL + ("%s %s" % [track.artist, track.title]).uri_encode())

func _on_refresh(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	for t in _parse(result, code, body):
		if t.id == track.id:
			track["preview"] = t.preview
			_fetch_audio()
			return
	status.emit("Превью недоступно")

func _fetch_cover() -> void:
	cover_tex = null
	cover_loaded.emit(null)
	var url: String = str(track.get("cover", ""))
	if url == "":
		return
	_h_cover.cancel_request()
	_h_cover.request(url)

func _on_cover(result: int, code: int, _h: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS or code != 200:
		return
	var img := Image.new()
	if img.load_jpg_from_buffer(body) != OK:
		return
	cover_tex = ImageTexture.create_from_image(img)
	cover_loaded.emit(cover_tex)

func toggle() -> void:
	if _player.stream == null:
		return
	if _player.playing:
		_paused_at = _player.get_playback_position()
		_player.stop()
		playing_changed.emit(false)
	else:
		_player.play(_paused_at)
		playing_changed.emit(true)

func is_playing() -> bool:
	return _player.playing

func next() -> void:
	if queue.is_empty():
		return
	play_index((index + 1) % queue.size(), true)

func prev() -> void:
	if queue.is_empty():
		return
	play_index((index - 1 + queue.size()) % queue.size(), true)

func set_volume(v: float) -> void:
	volume = clampf(v, 0.0, 1.0)
	_player.volume_db = linear_to_db(maxf(volume, 0.0001))
	Save.data.radio.volume = volume

# ---------- избранное и история ----------

func favorites() -> Array:
	return Save.data.radio.favorites

func history() -> Array:
	return Save.data.radio.history

func is_favorite(t: Dictionary) -> bool:
	for f in favorites():
		if f.id == t.get("id"):
			return true
	return false

func toggle_favorite() -> void:
	if track.is_empty():
		return
	var favs: Array = favorites()
	for i in favs.size():
		if favs[i].id == track.id:
			favs.remove_at(i)
			track_changed.emit(track)
			return
	favs.append(track.duplicate())
	track_changed.emit(track)

func _add_history(t: Dictionary) -> void:
	var h: Array = history()
	for i in range(h.size() - 1, -1, -1):
		if h[i].id == t.id:
			h.remove_at(i)
	h.push_front(t.duplicate())
	while h.size() > 50:
		h.pop_back()
