extends PanelContainer
## Интерфейс автомагнитолы. Музыка играет в автозагрузке Radio, поэтому закрытие панели её не останавливает.

var _list: ItemList
var _search: LineEdit
var _title: Label
var _artist: Label
var _status: Label
var _cover: TextureRect
var _play: TapBtn
var _fav: TapBtn
var _view: String = "results"
var _items: Array = []

func _btn(text: String, cb: Callable) -> TapBtn:
	var b := TapBtn.new()
	b.text = text
	b.tapped.connect(cb)
	return b

func _ready() -> void:
	var root := VBoxContainer.new()
	add_child(root)

	var row := HBoxContainer.new()
	root.add_child(row)
	_search = LineEdit.new()
	_search.placeholder_text = "Песня или исполнитель"
	_search.text = Save.data.radio.query
	_search.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_search.text_submitted.connect(_do_search)
	row.add_child(_search)
	row.add_child(_btn("Найти", func(): _do_search(_search.text)))
	row.add_child(_btn("Закрыть", hide))

	var body := HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	root.add_child(body)

	var left := VBoxContainer.new()
	left.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(left)
	var tabs := HBoxContainer.new()
	left.add_child(tabs)
	tabs.add_child(_btn("Результаты", func(): _set_view("results")))
	tabs.add_child(_btn("Избранное", func(): _set_view("favorites")))
	tabs.add_child(_btn("История", func(): _set_view("history")))
	_list = ItemList.new()
	_list.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_list.item_clicked.connect(_on_item)
	left.add_child(_list)

	var right := VBoxContainer.new()
	right.custom_minimum_size = Vector2(210, 0)
	body.add_child(right)
	_cover = TextureRect.new()
	_cover.custom_minimum_size = Vector2(200, 200)
	_cover.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	_cover.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	right.add_child(_cover)
	_title = Label.new()
	_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right.add_child(_title)
	_artist = Label.new()
	_artist.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	right.add_child(_artist)
	var ctrl := HBoxContainer.new()
	right.add_child(ctrl)
	ctrl.add_child(_btn("<<", Radio.prev))
	_play = _btn("Играть", Radio.toggle)
	ctrl.add_child(_play)
	ctrl.add_child(_btn(">>", Radio.next))
	_fav = _btn("В избранное", Radio.toggle_favorite)
	right.add_child(_fav)
	var vol := HSlider.new()
	vol.min_value = 0.0
	vol.max_value = 1.0
	vol.step = 0.01
	vol.value = Radio.volume
	vol.value_changed.connect(Radio.set_volume)
	right.add_child(vol)

	_status = Label.new()
	_status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_status.add_theme_font_size_override("font_size", 14)
	root.add_child(_status)
	_status.text = "Только превью 30 сек · источник Deezer"

	Radio.results_changed.connect(_refresh)
	Radio.track_changed.connect(_on_track)
	Radio.cover_loaded.connect(func(tex): _cover.texture = tex)
	Radio.playing_changed.connect(func(on): _play.text = "Пауза" if on else "Играть")
	Radio.status.connect(func(t): _status.text = t)
	visibility_changed.connect(_sync)
	_sync()

func _sync() -> void:
	_refresh()
	if not Radio.track.is_empty():
		_on_track(Radio.track)
		_cover.texture = Radio.cover_tex
	_play.text = "Пауза" if Radio.is_playing() else "Играть"

func _do_search(q: String) -> void:
	_set_view("results")
	Radio.search(q)

func _set_view(v: String) -> void:
	_view = v
	_refresh()

func _refresh() -> void:
	match _view:
		"favorites":
			_items = Radio.favorites()
		"history":
			_items = Radio.history()
		_:
			_items = Radio.results
	_list.clear()
	for t in _items:
		_list.add_item("%s — %s" % [t.artist, t.title])

func _on_item(i: int, _pos: Vector2, mb: int) -> void:
	if mb == MOUSE_BUTTON_LEFT:
		Radio.play_from(_items, i)

func _on_track(t: Dictionary) -> void:
	_title.text = str(t.title)
	_artist.text = str(t.artist)
	_fav.text = "Убрать из избранного" if Radio.is_favorite(t) else "В избранное"
