extends Node
## Автозагрузка "Save": всё сохранение в user://save.json

signal money_changed

const PATH := "user://save.json"
const AUTOSAVE_SEC := 10.0

var data: Dictionary = {}
var _t: float = 0.0

func _default() -> Dictionary:
	return {
		"version": 1,
		"money": 20000,
		"car_id": "cobalt",
		"owned": ["cobalt"],
		"color": "#d8d8d8",
		"plate": "",
		"fuel": 20.0,
		"damage": 0.0,
		"time": 9.0,
		"settings": {"steer_sens": 1.0, "graphics": 1, "auto_gearbox": true},
		"radio": {"volume": 0.8, "query": "", "index": 0, "favorites": [], "history": []},
	}

func _init() -> void:
	load_game()

func load_game() -> void:
	data = _default()
	if FileAccess.file_exists(PATH):
		var f := FileAccess.open(PATH, FileAccess.READ)
		if f:
			var parsed = JSON.parse_string(f.get_as_text())
			if parsed is Dictionary:
				_merge(data, parsed)

func _merge(base: Dictionary, src: Dictionary) -> void:
	for k in src:
		if base.has(k) and base[k] is Dictionary and src[k] is Dictionary:
			_merge(base[k], src[k])
		else:
			base[k] = src[k]

func save_game() -> void:
	var f := FileAccess.open(PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data))

func spend(amount: int) -> bool:
	if int(data.money) < amount:
		return false
	data.money = int(data.money) - amount
	money_changed.emit()
	return true

func add_money(amount: int) -> void:
	data.money = int(data.money) + amount
	money_changed.emit()

func _process(delta: float) -> void:
	_t += delta
	if _t >= AUTOSAVE_SEC:
		_t = 0.0
		save_game()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_game()
