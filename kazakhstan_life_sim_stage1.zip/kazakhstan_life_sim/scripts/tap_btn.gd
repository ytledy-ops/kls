class_name TapBtn
extends Button
## Кнопка, срабатывающая и вторым пальцем (пока первый держит газ).
## Godot эмулирует мышь только от первого касания, поэтому второе ловим сами.

signal tapped

var _last: float = -1.0

func _ready() -> void:
	focus_mode = Control.FOCUS_NONE
	pressed.connect(_fire)

func _fire() -> void:
	var now := Time.get_ticks_msec() / 1000.0
	if now - _last < 0.2:
		return
	_last = now
	tapped.emit()

func _input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and is_visible_in_tree() and not disabled:
		var t := event as InputEventScreenTouch
		if t.pressed and t.index > 0 and get_global_rect().has_point(t.position):
			_fire()
