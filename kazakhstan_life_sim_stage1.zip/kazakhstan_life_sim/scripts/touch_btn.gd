class_name TouchBtn
extends Panel
## Мультитач-кнопка педали: держит action, пока палец на ней (несколько пальцев одновременно)

var action: String = ""
var caption: String = ""
var _finger: int = -1

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.1, 0.1, 0.12, 0.55)
	sb.border_color = Color(1, 1, 1, 0.4)
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(24)
	add_theme_stylebox_override("panel", sb)
	var l := Label.new()
	l.text = caption
	l.set_anchors_preset(Control.PRESET_FULL_RECT)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", 28)
	add_child(l)

func _input(event: InputEvent) -> void:
	if not is_visible_in_tree():
		return
	if event is InputEventScreenTouch:
		var t := event as InputEventScreenTouch
		if t.pressed:
			if _finger == -1 and get_global_rect().has_point(t.position):
				_finger = t.index
				_press(true)
		elif t.index == _finger:
			_finger = -1
			_press(false)
	elif event is InputEventScreenDrag:
		var d := event as InputEventScreenDrag
		if d.index == _finger and not get_global_rect().has_point(d.position):
			_finger = -1
			_press(false)

func _press(on: bool) -> void:
	modulate = Color(1, 1, 1, 1.0) if on else Color(1, 1, 1, 0.75)
	if on:
		Input.action_press(action)
	else:
		Input.action_release(action)

func _exit_tree() -> void:
	Input.action_release(action)
